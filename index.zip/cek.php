<?php
session_start();
include 'koneksi.php'; // file untuk koneksi database

if (isset($_POST['cek'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk tabel admin
    $adminQuery = "SELECT * FROM admin WHERE username = ?";
    $stmtAdmin = $koneksi->prepare($adminQuery);
    $stmtAdmin->bind_param("s", $username);
    $stmtAdmin->execute();
    $resultAdmin = $stmtAdmin->get_result();

    if ($resultAdmin->num_rows > 0) {
        $adminData = $resultAdmin->fetch_assoc();

        // Verifikasi password tanpa enkripsi
        if ($password === $adminData['password']) {
            $_SESSION['user_id'] = $adminData['id'];
            $_SESSION['role'] = 'admin';
            $_SESSION['username'] = $adminData['username'];
            $_SESSION['nama'] = $adminData['nama'];
            $_SESSION['gambar'] = $adminData['gambar'];
            header("Location: admin/index.php");
            exit();
        }
    }

    // Query untuk tabel user (akun_guru)
    $userQuery = "SELECT * FROM akun_guru WHERE username = ?";
    $stmtUser = $koneksi->prepare($userQuery);
    $stmtUser->bind_param("s", $username);
    $stmtUser->execute();
    $resultUser = $stmtUser->get_result();

    if ($resultUser->num_rows > 0) {
        $userData = $resultUser->fetch_assoc();

        // Verifikasi password tanpa enkripsi
        if ($password === $userData['password']) {
            $_SESSION['user_id'] = $userData['id'];
            $_SESSION['role'] = 'guru';
            $_SESSION['username'] = $userData['username'];
            $_SESSION['nama'] = $userData['nama'];
            $_SESSION['gambar'] = $userData['gambar'];
            header("Location: guru/index.php");
            exit();
        }
    }

    // Jika login gagal (username atau password salah)
    header("Location: index.php?error=1");
    exit();
}
