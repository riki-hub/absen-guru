<?php
echo json_encode(['serverTime' => time()]);
